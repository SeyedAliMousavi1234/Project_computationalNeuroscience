
clc
clear
close all

%% setup for trial

set(0,'DefaultFigureWindowStyle','docked');
db = load('2015082011.mat');
% db = load('2015051115.mat');
no_of_trials = size(db.resp,1); % # of trials
sampling_frequency = 1000; % sampling frequency (in Hz)
i=0;
j=0;
condition_i=zeros(1,max(db.conds));
TuningCurve=zeros(1,max(db.conds));
W=0;
r=0;
S=db.conds(1);
for trial_no = 1:no_of_trials
    clf 
    
    time_of_saccade_onset_for_the_given_trial = double(db.tsaccade(trial_no)); % the time of saccade onset for the given trial
    condition_no_for_the_given_trial = double(db.conds(trial_no)); % the condition number for the given trial
    stim_sequence = double(db.stimcode(trial_no,:)); % the presented dot stimuli for the given trial
    spiking_response = double(db.resp(trial_no,:)); % the recorded spiking activity during the given trial

%% spike Train 

    for time_point = 1:length(spiking_response)
        the_screen = zeros(9,9);
        if 1<=stim_sequence(time_point) && stim_sequence(time_point)<=81
            [i,j] = ind2sub([9,9],stim_sequence(time_point));
            the_screen(i,j) = 1;
        end
        figure(1);
        subplot(5,1,[2,3])
        imagesc(1:9,1:9,the_screen), 
        axis xy, axis square, colormap gray, caxis([0 1])
        xlabel('X (in probe #)'), set(gca,'xtick',1:9)
        ylabel('Y (in probe #)'), set(gca,'ytick',1:9)
        title([...
            {['trial # ',num2str(trial_no),', condition # ',num2str(condition_no_for_the_given_trial)]},...
            {['time from start of the trial = ',num2str(time_point/sampling_frequency*1000),' ms']},...
            {['time from saccade onset = ',num2str((time_point-time_of_saccade_onset_for_the_given_trial)/sampling_frequency*1000),' ms']}])
        
        subplot(5,1,5)
        stem(((1:length(spiking_response))-time_of_saccade_onset_for_the_given_trial)/sampling_frequency*1000,spiking_response,'k','linewidth',2,'MarkerSize',0.0001)
        xlabel('time from saccade (ms)'), set(gca,'xtick',(0:50:length(spiking_response))-time_of_saccade_onset_for_the_given_trial)
        ylabel('spiking response'), set(gca,'ytick',[0 1])
        xlim([-100 +100]+time_point-time_of_saccade_onset_for_the_given_trial), ylim([0 1.2])
        pause(0.01)
    end

    %% fireing rate

    if(trial_no==no_of_trials)
        smooth1 = smooth(spiking_response,99);
        smooth_r=reshape(smooth1,length(spiking_response),1);
        time1 = 1:length(spiking_response);
        figure(2);
        plot(time1,smooth_r,'b','linewidth',1); 
        xlabel('time (ms)'); ylabel('firing rate ');
        title(['trial : ',num2str(trial_no),'  firing rate for condition number : ',num2str(condition_no_for_the_given_trial)]);
        pause(1)
        W=W+spiking_response;
        r=r+sum(spiking_response);
        i=i+1;
    end

    if(condition_no_for_the_given_trial==12)
        j=j+1;
        n(j)=sum(spiking_response);
    end

     %% Avrage fireing rate

    if (S ~= condition_no_for_the_given_trial || trial_no==no_of_trials)
        condition_i(S)=S;
        r=r/(length(spiking_response)*i);
        TuningCurve(S)=r;
        W=W/i;
        smooth1 = smooth(W,99);
        smooth_r=reshape(smooth1,length(spiking_response),1);
        figure(3);
        plot(time1,smooth_r,'b','linewidth',1); 
        xlabel('time (ms)'); ylabel('mean firing rate ');
        title(['mean firing rate  for condition number : ',num2str(S)]);
        pause(1.5)
        i=0;
        r=0;
        W=0;
        S=condition_no_for_the_given_trial;
    end 

    if(trial_no~=no_of_trials)
        smooth1 = smooth(spiking_response,99);
        smooth_r=reshape(smooth1,length(spiking_response),1);
        time1 = 1:length(spiking_response);
        figure(2);
        plot(time1,smooth_r,'b','linewidth',1); 
        xlabel('time (ms)'); ylabel('firing rate ');
        title(['trial : ',num2str(trial_no),'  firing rate for condition number : ',num2str(condition_no_for_the_given_trial)]);
        pause(1)
        W=W+spiking_response;
        r=r+sum(spiking_response);
        i=i+1;
    end
end

%% tunning curve

figure(4); 
plot(condition_i,TuningCurve,'k','LineWidth',3) ;
xlabel('condition number'); 
ylabel('Avg firing rate');
title ('tuning curve');

% fitting
fited = fit(condition_i',TuningCurve','gauss2');
figure(5);
plot(fited,condition_i,TuningCurve);
xlabel('the condition number for the given trial'); 
ylabel('Ave firing rate');
title ('fitting tuning curve( gussian)');

fited_2 = fit(condition_i',TuningCurve','smoothingspline');
figure(6);
plot(fited_2,condition_i,TuningCurve);
xlabel('the condition number for the given trial'); 
ylabel('Ave firing rate');title ('Fit smoothing splines in tuning Curve');

%% Fano factore

Mean=mean(n);
Var=var(n);
Fano_factor=Var/Mean;
%%%end